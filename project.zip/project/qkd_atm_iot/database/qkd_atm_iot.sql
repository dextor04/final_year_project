

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


CREATE TABLE `sat_admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `utype` varchar(20) NOT NULL,
  `bcode` varchar(20) NOT NULL,
  `url_link` varchar(100) NOT NULL,
  `uname2` varchar(20) NOT NULL,
  `pass2` varchar(20) NOT NULL,
  `block_count` int(11) NOT NULL,
  `pre_value` varchar(100) NOT NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `sat_admin` (`username`, `password`, `utype`, `bcode`, `url_link`, `uname2`, `pass2`, `block_count`, `pre_value`) VALUES
('admin1', 'admin1', 'admin', '1', 'iotcloud.co.in', 'admin1', '1234', 0, ''),
('cloud', '1234', 'authority', '2', '', 'cloud', '1234', 0, ''),
('kiruba', '1234', 'user', 'u1', '', 'kiruba1', '1234', 0, ''),
('vinay', '1234', 'user', 'u2', '', 'vinay1', '1234', 0, '');


CREATE TABLE `sat_data` (
  `id` int(11) NOT NULL,
  `satid` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mac_address` varchar(100) NOT NULL,
  `skey` varchar(20) NOT NULL,
  `user` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `sat_data` (`id`, `satid`, `name`, `mac_address`, `skey`, `user`) VALUES
(1, 'S1', 'TN233', '434FF-FDFD44-VFDF', '67f6274e', 'vinay');


CREATE TABLE `sat_files` (
  `id` int(11) NOT NULL,
  `satid` varchar(20) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `user` varchar(20) NOT NULL,
  `dtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `sat_user` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mac_address` varchar(100) NOT NULL,
  `user_key` varchar(20) NOT NULL,
  `satid` varchar(20) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `rdate` varchar(15) NOT NULL,
  `user` varchar(20) NOT NULL,
  `current_mac` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `uname` (`uname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `sat_user` (`id`, `name`, `mobile`, `email`, `mac_address`, `user_key`, `satid`, `uname`, `pass`, `rdate`, `user`, `current_mac`) VALUES
(1, 'Surya', 9070603011, 'surya@gmail.com', 'MF34D-GH89E-P42VN', 'aff8fbcb', 'S1', 'surya', '12345', '25-02-2022', 'kiruba', ''),
(2, 'Raj', 9956744332, 'raj@gmail.com', '9C-5A-44-4A-7C-26', '65a1223d', 'S2', 'raj', '12345', '25-02-2022', 'kiruba', '12-6F-D9-4B-CB-55'),
(3, 'Kirubanithi J', 8489958816, 'jkirubanithi14@gmail.com', '30-24-A9-3B-5E-0E', 'fbdb36fc', 'S3', 'kiruba14', '123456789', '21-03-2022', 'kiruba', '30-24-A9-3B-5E-0E');
