<?php
$connect=mysqli_connect("localhost","root","","qkd_atm_iot");
//$connect=mysqli_connect("localhost","iotcl6k4_iotuser","IOTcloud@2021","iotcl6k4_project22");
?>